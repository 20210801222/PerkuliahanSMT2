#ifndef QUICKSORTDESC_H    // To make sure you don't declare the function more than once by including the header multiple times.
#define QUICKSORTDESC_H

int quicksort(int *array, int left, int right);

#endif